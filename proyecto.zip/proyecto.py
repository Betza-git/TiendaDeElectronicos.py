# Definir usuarios y contraseñas en un diccionario
usuarios = {
    "usuario1": "usuario 1",  
    "usuario2": "usuario 2"   
}

# Mensaje de bienvenida para los clientes
print("Bienvenido a la tienda de electrónicos")

# Función para validar el login del usuario
def login():
    intentos = 3  # Número máximo de intentos permitidos
    while intentos > 0:  # Mientras haya intentos disponibles
        usuario = input("Ingrese su nombre de usuario: ")  # Solicitar nombre de usuario
        contraseña = input("Ingrese su contraseña: ")  # Solicitar contraseña
        if usuario in usuarios and usuarios[usuario] == contraseña:  # Verificar si el usuario y contraseña son correctos
            print("Ingreso satisfactorio.")  # Mensaje de éxito
            return True  # Retornar True si el login es exitoso
        else:
            intentos -= 1  # Contador para reducir el número de intentos restantes
            print(f"Usuario o contraseña incorrectos. Le quedan {intentos} intentos.")  # Mensaje de error
    print("Ha excedido el número de intentos. Saliendo de la plataforma.")  # Mensaje si se agotan los intentos
    return False  # Retornar False si el login falla

# Función para registrar información del cliente
def registrar_informacion(): # Solicitar información del cliente, cada input es una solicitud de información diferente
    nombre = input("Ingrese su nombre completo: ")  
    cedula = input("Ingrese su cédula: ")  
    celular = input("Ingrese su número de celular: ")  
    correo = input("Ingrese su correo electrónico: ")  
    direccion = input("Ingrese su dirección: ")  
    return {  # Retornar un diccionario con la información del cliente
        "Nombre": nombre,
        "Cédula": cedula,
        "Celular": celular,
        "Correo": correo,
        "Dirección": direccion
    }

# Función para mostrar el menú de opciones
def menu():
    print("\nMenú de opciones:")  # Mostrar título del menú, la \n es un salto de línea
    print("1. Ventas de paquetes")  
    print("2. Horarios disponibles de atención")  
    print("3. Productos disponibles")  
    print("4. Historial de compras")  
    print("5. Facturación de compras")  
    opcion = input("Seleccione una opción: ")  # Solicitar al usuario que seleccione una opción
    return opcion  # Retornar la opción seleccionada

# Función para facturación
def facturacion(cliente):
    subtotal = float(input("Ingrese el subtotal de la compra: "))  # Solicitar subtotal de la compra
    descuento = float(input("Ingrese el descuento aplicado: "))  # Solicitar descuento aplicado
    iva = subtotal * 0.12  # Calcular el IVA (12% del subtotal)
    total = subtotal - descuento + iva  # Calcular el total a pagar

    print("\nFacturación:")  # Mostrar título de la factura
    print(f"Nombre del cliente: {cliente['Nombre']}")  # Mostrar nombre del cliente
    print(f"Cédula: {cliente['Cédula']}")  # Mostrar cédula del cliente
    print(f"Correo: {cliente['Correo']}")  # Mostrar correo del cliente
    print(f"Subtotal: {subtotal}")  # Mostrar subtotal
    print(f"Descuento: {descuento}")  # Mostrar descuento
    print(f"IVA: {iva}")  # Mostrar IVA
    print(f"Total a pagar: {total}")  # Mostrar total a pagar

# Flujo principal del programa
if login():  # Si el login es exitoso
    cliente = registrar_informacion()  # Registrar información del cliente
    while True:  # Bucle infinito para mostrar el menú
        opcion = menu()  # Mostrar el menú y obtener la opción seleccionada
        if opcion == "5":  # Si el usuario selecciona la opción 5 (Facturación)
            facturacion(cliente)  # Llamar a la función de facturación
            break  # Salir del bucle y terminar el programa
        elif opcion in ["1", "2", "3", "4"]:  # Si el usuario selecciona una opción válida (1-4)
            print(f"Opción {opcion} seleccionada. (Funcionalidad no implementada en este ejemplo.)")  # Mensaje de opción no implementada
        else:
            print("Opción no válida. Intente nuevamente.")  # Mensaje de opción no válida